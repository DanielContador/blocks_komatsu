<?php
$plugin->component = 'block_dlmostviewed'; // Nombre del componente del plugin.
$plugin->version = 2025070400; // Versión en formato YYYYMMDDXX.
$plugin->requires = 2022041900; // Requiere Totara 13 o superior.